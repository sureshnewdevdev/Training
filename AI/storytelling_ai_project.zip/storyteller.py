from transformers import pipeline

# Load a text-generation model (creative model)
generator = pipeline("text-generation", model="gpt2")

def generate_story(title):
    # Create a storytelling prompt
    prompt = f"Write a short, creative story titled '{title}' for kids, with a moral at the end:\n\n"
    
    response = generator(
        prompt,
        max_length=250,
        do_sample=True,
        temperature=0.8,
        top_p=0.9,
        repetition_penalty=1.1
    )[0]["generated_text"]

    # Extract only the story part
    story = response.replace(prompt, "").strip()
    return story
