from flask import Flask, render_template, request
from storyteller import generate_story

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    title = request.form["title"]
    story = generate_story(title)
    return render_template("index.html", story=story, title=title)

if __name__ == "__main__":
    app.run(debug=True)
